CREATE VIEW view_practice AS
  SELECT
    `s`.`termYear`      AS `termYear`,
    `s`.`major`         AS `major`,
    `s`.`class`         AS `class`,
    `s`.`studentName`   AS `studentName`,
    `pr`.`practiceId`   AS `practiceId`,
    `pr`.`studentNo`    AS `studentNo`,
    `pr`.`practiceName` AS `practiceName`,
    `pr`.`type`         AS `type`,
    `pr`.`stuType`      AS `stuType`,
    `pr`.`startTime`    AS `startTime`,
    `pr`.`endTime`      AS `endTime`
  FROM (`test`.`student` `s`
    JOIN `test`.`practice` `pr`)
  WHERE (`s`.`studentNo` = `pr`.`studentNo`);
