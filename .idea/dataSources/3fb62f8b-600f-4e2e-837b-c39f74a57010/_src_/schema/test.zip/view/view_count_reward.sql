CREATE VIEW view_count_reward AS
  SELECT
    `s`.`termYear`    AS `nianji`,
    `r`.`rewardTime`  AS `xuenian`,
    `s`.`major`       AS `major`,
    `r`.`rewardLevel` AS `level`,
    `r`.`rewardName`  AS `name`,
    `j`.`adviser`     AS `adviser`,
    `r`.`sponsor`     AS `sponsor`
  FROM ((`test`.`student` `s`
    JOIN `test`.`jl` `j`) JOIN `test`.`rewardinfo` `r`)
  WHERE
    ((`s`.`studentNo` = `j`.`studentNo`) AND (`j`.`JLlevel` = `r`.`rewardLevel`) AND (`j`.`JLname` = `r`.`rewardName`)
     AND (`j`.`sponsor` = `r`.`sponsor`));
