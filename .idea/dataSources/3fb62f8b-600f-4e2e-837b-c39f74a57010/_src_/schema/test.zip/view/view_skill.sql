CREATE VIEW view_skill AS
  SELECT
    `s`.`termYear`    AS `termYear`,
    `s`.`major`       AS `major`,
    `s`.`class`       AS `class`,
    `s`.`studentName` AS `studentName`,
    `s`.`stuType`     AS `stuType`,
    `sk`.`skillId`    AS `skillId`,
    `sk`.`studentNo`  AS `studentNo`,
    `sk`.`skillName`  AS `skillName`,
    `sk`.`skillType`  AS `skillType`,
    `sk`.`gettime`    AS `gettime`
  FROM (`test`.`student` `s`
    JOIN `test`.`skill` `sk`)
  WHERE (`s`.`studentNo` = `sk`.`studentNo`);
