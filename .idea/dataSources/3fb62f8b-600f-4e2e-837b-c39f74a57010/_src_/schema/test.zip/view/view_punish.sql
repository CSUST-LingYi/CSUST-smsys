CREATE VIEW view_punish AS
  SELECT
    `s`.`termYear`     AS `termYear`,
    `s`.`major`        AS `major`,
    `s`.`class`        AS `class`,
    `s`.`studentName`  AS `studentName`,
    `s`.`stuType`      AS `stuType`,
    `p`.`id`           AS `id`,
    `p`.`studentNo`    AS `studentNo`,
    `p`.`punishName`   AS `punishName`,
    `p`.`punishReason` AS `punishReason`,
    `p`.`punishTime`   AS `punishTime`
  FROM (`test`.`student` `s`
    JOIN `test`.`punish` `p`)
  WHERE (`s`.`studentNo` = `p`.`studentNo`);
