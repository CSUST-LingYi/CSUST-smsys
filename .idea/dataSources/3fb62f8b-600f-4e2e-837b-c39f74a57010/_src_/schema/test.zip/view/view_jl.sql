CREATE VIEW view_jl AS
  SELECT
    `s`.`termYear`    AS `termYear`,
    `s`.`major`       AS `major`,
    `s`.`class`       AS `class`,
    `j`.`JLId`        AS `JLId`,
    `j`.`studentNo`   AS `studentNo`,
    `s`.`studentName` AS `studentName`,
    `j`.`adviser`     AS `adviser`,
    `j`.`sponsor`     AS `sponsor`,
    `s`.`stuType`     AS `stuType`,
    `j`.`JLname`      AS `JLname`,
    `j`.`JLlevel`     AS `JLlevel`,
    `j`.`getTime`     AS `getTime`
  FROM (`test`.`student` `s`
    JOIN `test`.`jl` `j`)
  WHERE (`s`.`studentNo` = `j`.`studentNo`);
