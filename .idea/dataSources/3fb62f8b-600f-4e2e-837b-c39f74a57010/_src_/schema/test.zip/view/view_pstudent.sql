CREATE VIEW view_pstudent AS
  SELECT
    `s`.`termYear`    AS `termYear`,
    `s`.`major`       AS `major`,
    `s`.`class`       AS `class`,
    `s`.`studentName` AS `studentName`,
    `s`.`stuType`     AS `stuType`,
    `ps`.`id`         AS `id`,
    `ps`.`pstudentNo` AS `pstudentNo`,
    `ps`.`SFZK`       AS `SFZK`,
    `ps`.`ZZname`     AS `ZZname`,
    `ps`.`type`       AS `type`,
    `ps`.`ZZmoney`    AS `ZZmoney`,
    `ps`.`ZZtime`     AS `ZZtime`
  FROM (`test`.`student` `s`
    JOIN `test`.`pstudent` `ps`)
  WHERE (`s`.`studentNo` = `ps`.`pstudentNo`);
