CREATE VIEW view_xjzc AS
  SELECT
    `s`.`termYear`    AS `termYear`,
    `s`.`major`       AS `major`,
    `s`.`class`       AS `class`,
    `s`.`studentName` AS `studentName`,
    `s`.`stuType`     AS `stuType`,
    `x`.`id`          AS `id`,
    `s`.`studentNo`   AS `studentNo`,
    `x`.`ZCyear`      AS `ZCyear`,
    `x`.`term`        AS `term`,
    `x`.`ZCorNot`     AS `ZCorNot`
  FROM (`test`.`student` `s` LEFT JOIN `test`.`xjzc` `x` ON ((`s`.`studentNo` = `x`.`studentNo`)));
