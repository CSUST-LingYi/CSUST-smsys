CREATE VIEW view_xjyd AS
  SELECT
    `s`.`termYear`    AS `termYear`,
    `s`.`studentName` AS `studentName`,
    `s`.`major`       AS `major`,
    `s`.`class`       AS `class`,
    `s`.`stuType`     AS `stuType`,
    `xd`.`id`         AS `id`,
    `xd`.`studentNo`  AS `studentNo`,
    `xd`.`YDtime`     AS `YDtime`,
    `xd`.`YDreason`   AS `YDreason`,
    `xd`.`BZ`         AS `BZ`
  FROM (`test`.`student` `s`
    JOIN `test`.`xjyd` `xd`)
  WHERE (`s`.`studentNo` = `xd`.`studentNo`);
